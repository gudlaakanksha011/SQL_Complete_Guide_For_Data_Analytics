create schema co;
use co;
-- Create the CUSTOMERS table to hold customer information

-- Create the CUSTOMERS table
CREATE TABLE customers (
  customer_id    INT NOT NULL AUTO_INCREMENT,
  email_address  VARCHAR(255) NOT NULL,
  full_name      VARCHAR(255) NOT NULL,
  PRIMARY KEY (customer_id),
  UNIQUE KEY customers_email_u (email_address),
  INDEX customers_name_i (full_name)
) ENGINE=InnoDB COMMENT='Details of the people placing orders';

select * from co.customers;

-- Create the STORES table
CREATE TABLE stores (
  store_id           INT NOT NULL AUTO_INCREMENT,
  store_name         VARCHAR(255) NOT NULL,
  web_address        VARCHAR(100),
  physical_address   VARCHAR(512),
  latitude           DECIMAL(9,6),
  longitude          DECIMAL(9,6),
  logo               BLOB,
  logo_mime_type     VARCHAR(512),
  logo_filename      VARCHAR(512),
  logo_charset       VARCHAR(512),
  logo_last_updated  DATETIME,
  PRIMARY KEY (store_id),
  UNIQUE KEY store_name_u (store_name),
  CONSTRAINT store_at_least_one_address_c CHECK (web_address IS NOT NULL OR physical_address IS NOT NULL)
) ENGINE=InnoDB COMMENT='Physical and virtual locations';

-- Create the PRODUCTS table
CREATE TABLE products (
  product_id           INT NOT NULL AUTO_INCREMENT,
  product_name         VARCHAR(255) NOT NULL,
  unit_price           DECIMAL(10,2),
  product_details      JSON, -- Changed to JSON type for native MySQL support
  product_image        LONGBLOB,
  image_mime_type      VARCHAR(512),
  image_filename       VARCHAR(512),
  image_charset        VARCHAR(512),
  image_last_updated   DATETIME,
  PRIMARY KEY (product_id)
) ENGINE=InnoDB COMMENT='Details of goods that customers can purchase';

-- Create the ORDERS table
CREATE TABLE orders (
  order_id      INT NOT NULL AUTO_INCREMENT,
  order_tms     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  customer_id   INT NOT NULL,
  order_status  VARCHAR(10) NOT NULL,
  store_id      INT NOT NULL,
  PRIMARY KEY (order_id),
  INDEX orders_customer_id_i (customer_id),
  INDEX orders_store_id_i (store_id),
  CONSTRAINT orders_status_c CHECK (order_status IN ('CANCELLED','COMPLETE','OPEN','PAID','REFUNDED','SHIPPED'))
) ENGINE=InnoDB;

-- Create the SHIPMENTS table
CREATE TABLE shipments (
  shipment_id      INT NOT NULL AUTO_INCREMENT,
  store_id         INT NOT NULL,
  customer_id      INT NOT NULL,
  delivery_address VARCHAR(512) NOT NULL,
  shipment_status  VARCHAR(100) NOT NULL,
  PRIMARY KEY (shipment_id),
  INDEX shipments_store_id_i (store_id),
  INDEX shipments_customer_id_i (customer_id),
  CONSTRAINT shipment_status_c CHECK (shipment_status IN ('CREATED', 'SHIPPED', 'IN-TRANSIT', 'DELIVERED'))
) ENGINE=InnoDB;

-- Create the ORDER_ITEMS table
CREATE TABLE order_items (
  order_id      INT NOT NULL,
  line_item_id  INT NOT NULL,
  product_id    INT NOT NULL,
  unit_price    DECIMAL(10,2) NOT NULL,
  quantity      INT NOT NULL,
  shipment_id   INT,
  PRIMARY KEY (order_id, line_item_id),
  UNIQUE KEY order_items_product_u (product_id, order_id),
  INDEX order_items_shipment_id_i (shipment_id)
) ENGINE=InnoDB;

-- Create the INVENTORY table
CREATE TABLE inventory (
  inventory_id       INT NOT NULL AUTO_INCREMENT,
  store_id           INT NOT NULL,
  product_id         INT NOT NULL,
  product_inventory  INT NOT NULL,
  PRIMARY KEY (inventory_id),
  UNIQUE KEY inventory_store_product_u (store_id, product_id),
  INDEX inventory_product_id_i (product_id)
) ENGINE=InnoDB;

-- Foreign Keys
ALTER TABLE orders ADD CONSTRAINT orders_customer_id_fk FOREIGN KEY (customer_id) REFERENCES customers (customer_id);
ALTER TABLE orders ADD CONSTRAINT orders_store_id_fk FOREIGN KEY (store_id) REFERENCES stores (store_id);
ALTER TABLE shipments ADD CONSTRAINT shipments_store_id_fk FOREIGN KEY (store_id) REFERENCES stores (store_id);
ALTER TABLE shipments ADD CONSTRAINT shipments_customer_id_fk FOREIGN KEY (customer_id) REFERENCES customers (customer_id);
ALTER TABLE order_items ADD CONSTRAINT order_items_order_id_fk FOREIGN KEY (order_id) REFERENCES orders (order_id);
ALTER TABLE order_items ADD CONSTRAINT order_items_shipment_id_fk FOREIGN KEY (shipment_id) REFERENCES shipments (shipment_id);
ALTER TABLE order_items ADD CONSTRAINT order_items_product_id_fk FOREIGN KEY (product_id) REFERENCES products (product_id);
ALTER TABLE inventory ADD CONSTRAINT inventory_store_id_fk FOREIGN KEY (store_id) REFERENCES stores (store_id);
ALTER TABLE inventory ADD CONSTRAINT inventory_product_id_fk FOREIGN KEY (product_id) REFERENCES products (product_id);

-- VIEWS

-- Customer Order Products View
CREATE OR REPLACE VIEW customer_order_products AS
  SELECT o.order_id, o.order_tms, o.order_status,
         c.customer_id, c.email_address, c.full_name,
         SUM(oi.quantity * oi.unit_price) AS order_total,
         GROUP_CONCAT(p.product_name ORDER BY oi.line_item_id SEPARATOR ', ') AS items
  FROM orders o
  JOIN order_items oi ON o.order_id = oi.order_id
  JOIN customers c ON o.customer_id = c.customer_id
  JOIN products p ON oi.product_id = p.product_id
  GROUP BY o.order_id, o.order_tms, o.order_status, c.customer_id, c.email_address, c.full_name;

-- Product Reviews View (MySQL 8.0+)
CREATE OR REPLACE VIEW product_reviews AS
  SELECT p.product_name, r.rating,
         ROUND(AVG(r.rating) OVER (PARTITION BY p.product_name), 2) AS avg_rating,
         r.review
  FROM products p,
       JSON_TABLE(p.product_details, '$.reviews[*]'
         COLUMNS (
           rating INT PATH '$.rating',
           review VARCHAR(4000) PATH '$.review'
         )
       ) AS r;

-- Product Orders View
CREATE OR REPLACE VIEW product_orders AS
  SELECT p.product_name, o.order_status,
         SUM(oi.quantity * oi.unit_price) AS total_sales,
         COUNT(*) AS order_count
  FROM orders o
  JOIN order_items oi ON o.order_id = oi.order_id
  JOIN products p ON oi.product_id = p.product_id
  GROUP BY p.product_name, o.order_status;