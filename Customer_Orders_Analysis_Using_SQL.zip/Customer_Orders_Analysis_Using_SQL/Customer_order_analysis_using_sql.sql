use co;
-- after getting data check for the columns in the data
-- COLUMNS are : {customers, orders.products,order_items,stores}

-- then check for fill rates ( no.of rows)
select count(*) from orders;
select * from orders;

select count(*) from shipments;
select * from shipments;

select count(*) from order_items;
select * from order_items;

select count(*) from stores;
select * from stores;

select count(*) from products;
select * from products;

select count(*) from inventory;
select * from inventory;

-- find the no.of customers in customers table
select count(*) from customers;
select * from customers;
select count(distinct customer_id) from customers; -- {distinct eliminates duplicate values}

-- Find if there are any duplicate name/email in customers data?
select full_name,count(full_name) as cnt
from customers
group by full_name
having cnt > 1;

select email_address,count(email_address) as cnt
from customers
group by email_address
having cnt > 1;
-- the data inside the table can be case sensitive so use upper or lower
select upper(full_name),count(upper(full_name)) as cnt
from customers
group by upper(full_name)
having cnt > 1;

select upper(email_address),count(upper(email_address)) as cnt
from customers
group by upper(email_address)
having cnt > 1;

-- what are all the order-status possible values are there as per data?
select upper(order_status), count(*) as cnt
from orders
group by upper(order_status);

-- Do we have returned/cancelled included in the orders table?
select * from order_items
where order_id in (select order_id from orders where order_status in('REFUNDED','CANCELLED'));

-- find the total revenue including cancelled/returned?
select sum(unit_price * quantity) as total_revenue
from order_items;

-- find the total revenue(only for "complete" orders)
select sum(unit_price * quantity) as total_revenue
from order_items
where order_id in (select order_id from orders where order_status in ('COMPLETE'));

-- which product is most sold by count?
select product_id, sum(quantity) as total_products_sold
from order_items
group by product_id
order by sum(quantity) desc;

-- which product is least sold by count?
select product_id, sum(quantity) as total_products_sold
from order_items
group by product_id
order by sum(quantity) asc;

-- Find the name of the most sold  products?
SELECT a.product_id, b.product_name, SUM(a.quantity) AS total_products_sold
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold DESC;

-- Find the name of the least sold  products?
SELECT a.product_id, b.product_name, SUM(a.quantity) AS total_products_sold
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold asc;

-- Find the name of the top 3  most sold  products ?
SELECT a.product_id, b.product_name, SUM(a.quantity) AS total_products_sold
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold DESC
limit 3;

-- Find the name of the top 3 least sold  products ?
SELECT a.product_id, b.product_name, SUM(a.quantity) AS total_products_sold
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold asc
limit 3;

-- find the revenue for each store?
select a.store_id,c.store_name,sum(unit_price * quantity) as total_revenue_by_store
from orders a join order_items b
on a.order_id = b.order_id
join stores c
on a.store_id = c.store_id
group by a.store_id,c.store_name;

-- Find the store which has highest revenue 
select a.store_id,c.store_name,sum(unit_price * quantity) as total_revenue_by_store
from orders a join order_items b
on a.order_id = b.order_id
join stores c
on a.store_id = c.store_id
group by a.store_id,c.store_name
order by total_revenue_by_store desc;

-- find the revenue for each store using CTE or with clause?
WITH cte1 AS (
    SELECT 
        a.store_id,
        SUM(b.unit_price * b.quantity) AS total_revenue_by_store
    FROM orders a 
    JOIN order_items b ON a.order_id = b.order_id
    GROUP BY a.store_id
)
SELECT 
    b.store_name, 
    a.total_revenue_by_store
FROM cte1 a 
JOIN stores b ON a.store_id = b.store_id
group by b.store_name;

-- find the highest revenue of the store using CTE or with clause?
WITH cte1 AS (
    SELECT 
        a.store_id,
        SUM(b.unit_price * b.quantity) AS total_revenue_by_store
    FROM orders a 
    JOIN order_items b ON a.order_id = b.order_id
    GROUP BY a.store_id
)
SELECT 
    b.store_name, 
    a.total_revenue_by_store
FROM cte1 a 
JOIN stores b ON a.store_id = b.store_id
group by b.store_name
order by total_revenue_by_store desc;

-- Find the most sold product by revenue
select product_id, sum(unit_price * quantity) as total_products_sold_by_revenue
from order_items
group by product_id
order by total_products_sold_by_revenue desc;

-- Find the name of the most sold  products by revenue?
SELECT a.product_id, b.product_name, SUM(a.unit_price*quantity) AS total_products_sold_by_revenue
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold_by_revenue DESC;

-- Find the name of the most sold top3 products by revenue?
SELECT a.product_id, b.product_name, SUM(a.unit_price*quantity) AS total_products_sold_by_revenue
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold_by_revenue DESC
limit 3;

-- Find the least sold product by revenue
select product_id, sum(unit_price * quantity) as total_products_sold_by_revenue
from order_items
group by product_id
order by total_products_sold_by_revenue asc;

-- Find the name of the least sold  products by revenue?
SELECT a.product_id, b.product_name, SUM(a.unit_price*quantity) AS total_products_sold_by_revenue
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold_by_revenue ASC;

-- Find the name of the least sold top3 products by revenue?
SELECT a.product_id, b.product_name, SUM(a.unit_price*quantity) AS total_products_sold_by_revenue
FROM order_items a 
INNER JOIN products b ON a.product_id = b.product_id
GROUP BY a.product_id, b.product_name
ORDER BY total_products_sold_by_revenue asc
limit 3;






